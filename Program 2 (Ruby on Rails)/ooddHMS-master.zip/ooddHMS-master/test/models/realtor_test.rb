require 'test_helper'

class RealtorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
