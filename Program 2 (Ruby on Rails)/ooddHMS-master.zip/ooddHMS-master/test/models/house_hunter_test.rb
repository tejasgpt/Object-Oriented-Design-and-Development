require 'test_helper'

class HouseHunterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
