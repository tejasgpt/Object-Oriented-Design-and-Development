require 'test_helper'

class AdminprofileControllerTest < ActionDispatch::IntegrationTest
  test "should get showadmin" do
    get adminprofile_showadmin_url
    assert_response :success
  end

end
