require 'test_helper'

class HousehunterprofileControllerTest < ActionDispatch::IntegrationTest
  test "should get showprofile" do
    get househunterprofile_showprofile_url
    assert_response :success
  end

end
