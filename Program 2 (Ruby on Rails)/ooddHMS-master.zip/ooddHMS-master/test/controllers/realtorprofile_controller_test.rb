require 'test_helper'

class RealtorprofileControllerTest < ActionDispatch::IntegrationTest
  test "should get houses" do
    get realtorprofile_houses_url
    assert_response :success
  end

end
