require 'test_helper'

class RecompaniesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @recompany = recompanies(:one)
  end

  test "should get index" do
    get recompanies_url
    assert_response :success
  end

  test "should get new" do
    get new_recompany_url
    assert_response :success
  end

  test "should create recompany" do
    assert_difference('Recompany.count') do
      post recompanies_url, params: { recompany: { address: @recompany.address, founded: @recompany.founded, name: @recompany.name, revenue: @recompany.revenue, size: @recompany.size, synopsis: @recompany.synopsis, website: @recompany.website } }
    end

    assert_redirected_to recompany_url(Recompany.last)
  end

  test "should show recompany" do
    get recompany_url(@recompany)
    assert_response :success
  end

  test "should get edit" do
    get edit_recompany_url(@recompany)
    assert_response :success
  end

  test "should update recompany" do
    patch recompany_url(@recompany), params: { recompany: { address: @recompany.address, founded: @recompany.founded, name: @recompany.name, revenue: @recompany.revenue, size: @recompany.size, synopsis: @recompany.synopsis, website: @recompany.website } }
    assert_redirected_to recompany_url(@recompany)
  end

  test "should destroy recompany" do
    assert_difference('Recompany.count', -1) do
      delete recompany_url(@recompany)
    end

    assert_redirected_to recompanies_url
  end
end
