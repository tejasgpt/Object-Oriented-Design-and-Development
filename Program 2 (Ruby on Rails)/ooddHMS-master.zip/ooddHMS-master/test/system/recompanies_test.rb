require "application_system_test_case"

class RecompaniesTest < ApplicationSystemTestCase
  setup do
    @recompany = recompanies(:one)
  end

  test "visiting the index" do
    visit recompanies_url
    assert_selector "h1", text: "Recompanies"
  end

  test "creating a Recompany" do
    visit recompanies_url
    click_on "New Recompany"

    fill_in "Address", with: @recompany.address
    fill_in "Founded", with: @recompany.founded
    fill_in "Name", with: @recompany.name
    fill_in "Revenue", with: @recompany.revenue
    fill_in "Size", with: @recompany.size
    fill_in "Synopsis", with: @recompany.synopsis
    fill_in "Website", with: @recompany.website
    click_on "Create Recompany"

    assert_text "Recompany was successfully created"
    click_on "Back"
  end

  test "updating a Recompany" do
    visit recompanies_url
    click_on "Edit", match: :first

    fill_in "Address", with: @recompany.address
    fill_in "Founded", with: @recompany.founded
    fill_in "Name", with: @recompany.name
    fill_in "Revenue", with: @recompany.revenue
    fill_in "Size", with: @recompany.size
    fill_in "Synopsis", with: @recompany.synopsis
    fill_in "Website", with: @recompany.website
    click_on "Update Recompany"

    assert_text "Recompany was successfully updated"
    click_on "Back"
  end

  test "destroying a Recompany" do
    visit recompanies_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Recompany was successfully destroyed"
  end
end
