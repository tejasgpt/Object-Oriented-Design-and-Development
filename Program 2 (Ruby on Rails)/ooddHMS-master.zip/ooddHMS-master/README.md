Login Credentials for Admin Email: admin1@gmail.com Password: Admin123

Link for the application hosted on AWS:  https://18.224.197.227:8080/

Admin capable of performing majority of realtor and househunter operations.

Realtor - Create a new profile or login with existing one.
          username - realtor@test.com
          password - realtorpassword
 

