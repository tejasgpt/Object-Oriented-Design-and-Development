class AdminprofileController < ApplicationController
  def showadmin
  end
end
