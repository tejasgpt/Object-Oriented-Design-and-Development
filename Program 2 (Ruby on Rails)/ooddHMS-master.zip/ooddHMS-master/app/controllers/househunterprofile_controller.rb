class HousehunterprofileController < ApplicationController
  def showprofile
    # binding.irb
    # @house_hunter = HouseHunter.find(params[:id])
    # @house_hunter_inquiries= @house_hunter.inquiries
    #render "househunterprofile/showprofile"
  end
end
