class Recompany < ApplicationRecord
  has_many :Realtor
end
