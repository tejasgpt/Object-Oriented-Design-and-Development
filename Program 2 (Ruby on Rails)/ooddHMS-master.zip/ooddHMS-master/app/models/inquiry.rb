class Inquiry < ApplicationRecord
  belongs_to :house_hunter
    #:optional => true
end
